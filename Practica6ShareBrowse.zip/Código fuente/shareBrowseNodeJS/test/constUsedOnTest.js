//Pruebas Unitarias con Mocha y librería Chai
//Constantes usadas en los test
//https://www.chaijs.com/api/bdd/

// PARA EJECUTAR EL TEST ESCRIBIR
// npm test
// EN LA LINEA DE COMANDOS

const app = require("../app.js");
