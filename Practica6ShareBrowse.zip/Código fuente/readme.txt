Al tratarse de un proyecto cliente servidor en esta carpeta se encuentran dos subproyectos:
· La extensión para chrome (el cliente)
· La aplicación del lado del servidor implementada en nodejs (dentro están las pruebas)

Tal y cómo ya se ha explicado en otro readme, en la carpeta principal, este tipo de proyectos no generan archivos compilables, por lo que la única opción para correrlos es disponer de Google Chrome e insertar la extensión para la aplicación del cliente y disponer de NodeJS versión 10.15.1 para ejecutar el proyecto servidor ejecutando los comandos, mediante una terminal: "npm install", "node app.js". 

Otra opción, para evitar al menos, tener que instalar nodejs para correr el aplicativo servidor, sería el tenerlo alojado en un servidor, pero debido a que cobran o dan tiempos de prueba muy reducidos para disponer de máquinas virtuales en la nube, no se ha podido llevar a cabo esta opción. No obstante, el servidor que aloja la base de datos MongoDB está en la nube porque nos ofrecían una solución lenta pero gratuita, y de esta forma facilitar el despliegue.

Se adjunta un video de cómo funciona el proyecto.

Para añadir la extensión a chrome, se debe abrir el navegador e incluir en la barra de direcciones "chrome://extensions/". En esta página se debe habilitar el modo desarrollador (arriba a la dcha) y a continuación, utilizar la opción "Cargar sin comprimir". Se debe seleccionar el interior de la carpeta principal de la extensión adjunta en códigos fuentes.

Una cuenta de usuario con datos es "correo1@gmail.com" y contraseña "1234567a". Para registrar una nueva cuenta la contraseña debe tener 8 o más caracteres.