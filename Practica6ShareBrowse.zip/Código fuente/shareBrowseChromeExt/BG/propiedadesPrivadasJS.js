var apiURL= "http://localhost:8080/api/";
var apiURLLoginSignIn= "http://localhost:8080/";
var loginPageUrl= chrome.runtime.getURL("/loginPage.html");
var timeoutLogin= null;