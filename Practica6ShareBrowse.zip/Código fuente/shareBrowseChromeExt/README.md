# shareBrowseChromeExt
UCM University project about sharing browse navigation data between some browsers. This repository describes the extension for Google Chrome.
